<hr>
    <p>Made by Emil Hilbert Jensen</p>
    </body>
    </html>
<!-- Footer som bliver implementeret via php implement funktionen, på alle sider-->